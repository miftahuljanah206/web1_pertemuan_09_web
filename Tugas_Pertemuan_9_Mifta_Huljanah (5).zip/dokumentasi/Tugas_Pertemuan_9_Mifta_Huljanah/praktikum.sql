-- Praktikum Pemrograman Web I Pertemuan 9
-- Nama: Mifta Huljanah | NIM: 25012033 | Kelas: 25M11
-- Basis data relasional dan SQL CRUD
-- Jalankan pada basis data latihan baru. Jangan menjalankan INSERT berulang tanpa memeriksa data.

CREATE DATABASE IF NOT EXISTS web1_pertemuan09
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE web1_pertemuan09;

-- A. Membuat tabel kategori dan produk
CREATE TABLE IF NOT EXISTS kategori (
  id_kategori INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nama_kategori VARCHAR(80) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS produk (
  id_produk INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  id_kategori INT UNSIGNED NOT NULL,
  nama_produk VARCHAR(120) NOT NULL,
  harga DECIMAL(12,2) NOT NULL,
  stok INT UNSIGNED NOT NULL DEFAULT 0,
  CONSTRAINT fk_produk_kategori
    FOREIGN KEY (id_kategori) REFERENCES kategori(id_kategori)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

-- B. Memasukkan data awal (jalankan satu kali pada basis data yang masih kosong)
INSERT INTO kategori (id_kategori, nama_kategori) VALUES
  (1, 'Alat Tulis'),
  (2, 'Aksesori Komputer'),
  (3, 'Perlengkapan Kelas');

INSERT INTO produk (id_produk, id_kategori, nama_produk, harga, stok) VALUES
  (1, 1, 'Buku Catatan', 12000.00, 20),
  (2, 1, 'Pulpen Gel', 6500.00, 35),
  (3, 2, 'Mouse USB', 85000.00, 8),
  (4, 2, 'Flashdisk 32 GB', 78000.00, 12),
  (5, 3, 'Spidol Papan', 15000.00, 10);

-- C. Memeriksa struktur dan jumlah data
SHOW TABLES;
DESCRIBE kategori;
DESCRIBE produk;
SELECT COUNT(*) AS jumlah_kategori FROM kategori;
SELECT COUNT(*) AS jumlah_produk FROM produk;

-- D. READ: menampilkan seluruh produk
SELECT id_produk, nama_produk, harga, stok
FROM produk
ORDER BY id_produk;

-- E. READ: produk dengan stok kurang dari 15
SELECT nama_produk, stok
FROM produk
WHERE stok < 15
ORDER BY stok ASC;

-- F. READ: JOIN produk dengan kategori
SELECT p.id_produk, p.nama_produk, k.nama_kategori, p.harga, p.stok
FROM produk AS p
INNER JOIN kategori AS k ON p.id_kategori = k.id_kategori
ORDER BY k.nama_kategori, p.nama_produk;

-- G. READ: jumlah produk per kategori, termasuk kategori kosong
SELECT k.nama_kategori, COUNT(p.id_produk) AS jumlah_produk
FROM kategori AS k
LEFT JOIN produk AS p ON p.id_kategori = k.id_kategori
GROUP BY k.id_kategori, k.nama_kategori
ORDER BY k.nama_kategori;

-- H. UPDATE: mengubah harga dan stok Pulpen Gel; periksa sebelum/sesudah
SELECT id_produk, nama_produk, harga, stok
FROM produk WHERE id_produk = 2;

UPDATE produk
SET harga = 7000.00, stok = 30
WHERE id_produk = 2;

SELECT id_produk, nama_produk, harga, stok
FROM produk WHERE id_produk = 2;

-- I. DELETE: menghapus hanya Spidol Papan; periksa sebelum/sesudah
SELECT id_produk, nama_produk FROM produk WHERE id_produk = 5;
DELETE FROM produk WHERE id_produk = 5;
SELECT id_produk, nama_produk FROM produk WHERE id_produk = 5;
SELECT COUNT(*) AS jumlah_produk FROM produk;

-- J. Tugas mandiri 1: tambah kategori baru.
-- Ambil id kategori hasil INSERT dengan SELECT; jangan menebak ID.
INSERT INTO kategori (nama_kategori)
VALUES ('Kebutuhan Lab');

SET @id_kebutuhan_lab = (
  SELECT id_kategori FROM kategori
  WHERE nama_kategori = 'Kebutuhan Lab'
);

-- Tambahkan dua produk pada kategori baru.
INSERT INTO produk (id_kategori, nama_produk, harga, stok) VALUES
  (@id_kebutuhan_lab, 'Kabel LAN 2 Meter', 18000.00, 15),
  (@id_kebutuhan_lab, 'Mouse Pad', 12000.00, 20);

-- Pastikan data dan ID kategori yang digunakan benar.
SELECT @id_kebutuhan_lab AS id_kategori_kebutuhan_lab;
SELECT p.id_produk, p.nama_produk, k.nama_kategori, p.harga, p.stok
FROM produk AS p
INNER JOIN kategori AS k ON p.id_kategori = k.id_kategori
WHERE k.nama_kategori = 'Kebutuhan Lab';

-- Tugas mandiri 2: produk dengan harga 10.000 sampai 100.000,
-- diurutkan dari harga tertinggi.
SELECT id_produk, nama_produk, harga, stok
FROM produk
WHERE harga BETWEEN 10000 AND 100000
ORDER BY harga DESC;

-- Tugas mandiri 3: nama kategori dan jumlah produk termasuk kategori kosong.
SELECT k.nama_kategori, COUNT(p.id_produk) AS jumlah_produk
FROM kategori AS k
LEFT JOIN produk AS p ON p.id_kategori = k.id_kategori
GROUP BY k.id_kategori, k.nama_kategori
ORDER BY k.nama_kategori;

-- Tugas mandiri 4: ubah stok satu produk yang ditambahkan.
SELECT id_produk, nama_produk, stok
FROM produk WHERE nama_produk = 'Kabel LAN 2 Meter';

UPDATE produk
SET stok = 18
WHERE nama_produk = 'Kabel LAN 2 Meter'
  AND id_kategori = @id_kebutuhan_lab;

SELECT id_produk, nama_produk, stok
FROM produk WHERE nama_produk = 'Kabel LAN 2 Meter';

-- Hapus produk lain yang ditambahkan; hanya Mouse Pad yang dihapus.
SELECT id_produk, nama_produk
FROM produk WHERE nama_produk = 'Mouse Pad'
  AND id_kategori = @id_kebutuhan_lab;

DELETE FROM produk
WHERE nama_produk = 'Mouse Pad'
  AND id_kategori = @id_kebutuhan_lab;

SELECT id_produk, nama_produk
FROM produk WHERE nama_produk = 'Mouse Pad'
  AND id_kategori = @id_kebutuhan_lab;

-- Tugas mandiri 5 / uji integritas relasi:
-- Query berikut memang diharapkan gagal karena kategori 99 tidak tersedia.
-- Jalankan TERPISAH setelah query lain, lalu catat pesan error.
-- INSERT INTO produk (id_kategori, nama_produk, harga, stok)
-- VALUES (99, 'Produk Tanpa Kategori', 10000.00, 1);

-- Query berikut juga diharapkan gagal karena kategori 1 masih dipakai produk.
-- Jalankan TERPISAH dan catat pesan error.
-- DELETE FROM kategori WHERE id_kategori = 1;

-- Pemeriksaan akhir
SELECT COUNT(*) AS jumlah_kategori FROM kategori;
SELECT COUNT(*) AS jumlah_produk FROM produk;
SELECT p.id_produk, p.nama_produk, k.nama_kategori, p.harga, p.stok
FROM produk AS p
INNER JOIN kategori AS k ON p.id_kategori = k.id_kategori
ORDER BY k.nama_kategori, p.nama_produk;
